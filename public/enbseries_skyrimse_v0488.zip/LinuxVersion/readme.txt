//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

PUBLISHING BINARY FILES OF ENBSERIES ON NEXUS SITES (FALLOUT NEXUS, TES NEXUS, ETC)
IS STRICTLY PROHIBITED. ONLY PRESETS AND SHADERS CAN BE HOSTED THERE.



This build have Skylighting, parallax effects disabled and potentially any other dependent which
are not compatible with Linux. Use it if regular version do not works for you.


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//INSTALL
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Following guide is made by Linux user:


TES Skyrim SE with ENBSeries running on "current" versions of WINE with DXVK:
As there can be many different hardware configurations, and even more software configurations, and I expect many of these combinations will work with a somewhat common set of rules, I'm going to list out the configuration that has worked for me.

In general, so long as you have the right versions of these applications installed, things should work basically the same as they do on Windows.

TES Skyrim SE version: 1.5.97.0.8
WINE version: lutris-6.4-x86_64 (also tested on Proton-6.5-GE-1)
Winetricks: d3dx11_43, d3dcompiler_43, d3dcompiler_47 (specific version of d3dcompiler likely doesn't matter)
DXVK version: v1.7.3L-03f11ba
Vulkan Instance Version: 1.2.141
Lutris version: 0.5.8.3
OS: Kubuntu 20.10
Video Card: NVidia GeForce GTX 980
ENBSeries Presets tested: Cathedral Minimalist ENB https://www.nexusmods.com/skyrimspecial ... mods/31367
Mods: This worked with no mods enabled, and 50 mods installed, so it seems pretty robust.
More than likely the major version of WINE and DXVK version range are the most critical here. I expect that any WINE 6.x version will work, and probably any DXVK that was built since WINE 6.x
While I tested this via Lutris, I don't think it is needed at all. You can likely run straight from Steam for Linux with a version of Proton that uses DXVK. You should theoretically be able to run whatever executable is required to run the game as you want it, be that via a launcher, mod tool, Steam, etc, from the terminal via your versions of wine, just by pointing your version of wine to the exe.

I find Lutris to be a nice way to run this, as it will handle installation of a lot of the components for you, such as WINE, and DXVK, and has installers for Skyrim for Steam:
https://lutris.net/games/the-elder-scrolls-v-skyrim-special-edition/

Follow the instructions from your ENBSeries preset on installation. Just be sure to use enbseries for TES Skyrim SE version 0.347 or (insert version name/number of the newer version that is released specifically for Linux)


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//USED THIRD PARTY CODE/MIDDLEWARE AND THEIR LICENSES (THESE ARE NOT MOD LICENSES)
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Using AntTweakBar
Copyright (C) 2005-2019 Philippe Decaudin
AntTweakBar web site: http://www.antisphere.com


Using 3Dmigoto
3Dmigoto authors: Chiri, Bo3b Johnson, Ulf Jalmgrant (AKA Flugan), Ian Munsie (AKA DarkStarSword)

The MIT License (MIT)

Copyright (c) 2014-2019 the 3Dmigoto project authors (see the file AUTHORS.txt
for a complete list)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
http://enbdev.com
Copyright (c) 2007-2021 Vorontsov Boris (ENB developer)
